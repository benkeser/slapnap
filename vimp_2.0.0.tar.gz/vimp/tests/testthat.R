library(testthat)
library(vimp)

test_check("vimp")
