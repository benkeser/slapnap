context("test_vimp_accuracy.R")

## load required functions and packages
library("testthat")
library("SuperLearner")
library("vimp")

## generate the data
make_y <- function(b, p) rbinom(b, 1, p)
make_x <- function(b, mu_0, mu_1, sigma, y) {
  n_col <- ifelse(!is.null(dim(mu_0)), dim(mu_0)[2], length(mu_0))
  x <- matrix(0, nrow = b, ncol = n_col)
  x[y == 0, ] <- MASS::mvrnorm(n = sum(y == 0), mu = mu_0, Sigma = sigma)
  x[y == 1, ] <- MASS::mvrnorm(n = sum(y == 1), mu = mu_1, Sigma = sigma)
  if (n_col == 1) {
    x <- cbind(x, stats::rnorm(b, 0, 1))
  }
  return(x)
}
gen_data <- function(a, mu_0, mu_1, sigma, p, j) {
  ## create y
  y <- make_y(a, p)
  # create x
  # x <- make_x(a)
  x <- make_x(a, mu_0, mu_1, sigma, y)
  red_x <- x[, -j]
  
  return(list(x = x, red_x = red_x, y = y, j = j))
}
mu_0 <- matrix(c(0, 0), nrow = 1)
mu_1 <- matrix(c(1.5, 2), nrow = 1)
Sigma <- diag(1, nrow = 2)
t <- c(0.05110135, 0.1158337)
n <- 10000
set.seed(4747)
dat <- gen_data(n, mu_0, mu_1, Sigma, p = 0.6, j = 1)
y <- dat$y
x <- as.data.frame(dat$x)

## set up a library for SuperLearner
learners <- "SL.gam"

## fit the data with all covariates
full_fit <- SuperLearner(Y = y, X = x, SL.library = learners, family = "binomial")
full_fitted <- predict(full_fit)$pred

## fit the data with only X1
reduced_fit <- SuperLearner(Y = y, X = x[, -1, drop = FALSE], SL.library = learners, family = "binomial")
reduced_fitted <- predict(reduced_fit)$pred

test_that("Test accuracy-based variable importance", {
  est <- vimp_accuracy(Y = y, f1 = full_fitted, f2 = reduced_fitted, run_regression = FALSE, indx = 1)
  expect_equal(est$est, t[1], tolerance = 0.02)
})
