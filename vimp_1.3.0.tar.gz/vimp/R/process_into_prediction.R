#' Create a \code{prediction} class object from predicted values and class labels
